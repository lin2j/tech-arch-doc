package com.jia.spidemo;

/**
 * @author linjinjia
 * @date 2023/7/3 10:07
 */
public class MySqlSearch implements DataSearch {

    @Override
    public void search() {
        System.out.println("MySQL Search");
    }
}