package com.jia.spidemo;

import java.util.Iterator;
import java.util.ServiceLoader;

/**
 * @author linjinjia
 * @date 2023/7/3 10:14
 */
public class Application {

    public static void main(String[] args) {
        ServiceLoader<DataSearch> serviceLoader = ServiceLoader.load(DataSearch.class);
        Iterator<DataSearch> iterator = serviceLoader.iterator();
        while (iterator.hasNext()) {
            DataSearch ds = iterator.next();
            ds.search();
        }
    }
}