package com.jia.spidemo;

/**
 * @author linjinjia
 * @date 2023/7/3 10:03
 */
public interface DataSearch {

    /**
     * 数据查询
     */
    void search();
}