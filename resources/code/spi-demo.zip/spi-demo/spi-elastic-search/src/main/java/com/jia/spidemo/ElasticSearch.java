package com.jia.spidemo;

/**
 * @author linjinjia
 * @date 2023/7/3 10:05
 */
public class ElasticSearch implements DataSearch{
    @Override
    public void search() {
        System.out.println("Elastic Search");
    }
}