public class exceptiontest2 {

    public static void throwexcep() {
        int i = 1 / 0;
    }

    public static string wrap() {
        try {
            throwexcep();
            return "ok";
        } catch (exception e2) {
            e2.printstacktrace();
            return "error";
        } finally {
            system.out.println("finally block");
        }
    }
    
    public static void main(string[] args) {
        wrap();
    }
}
