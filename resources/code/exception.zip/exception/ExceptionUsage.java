import java.util.concurrent.TimeUnit;

/**
 * @author linjinjia
 * @date 2023/7/3 17:57
 */
public class ExceptionUsage {

    /**
     * 自定义检查异常（运行时异常）
     */
    private static class MyCheckedException extends Exception {
    }

    /**
     * 自定义不可查异常（编译时异常）
     */
    private static class MyUncheckedException extends RuntimeException {
    }

    /**
     * 自定义自动关闭的资源
     */
    private static class AutoCloseableResource implements AutoCloseable {
        @Override
        public void close() throws Exception {
            // 使用 try-with-resources 的方式，
            // 即使我们没有显式调用这个方法，它也会自动执行
            System.out.println("try-with-resources: 自动关闭资源");
        }
    }

    /**
     * 该方法会声明并抛出一个编译时异常，调用方必须处理异常
     */
    public static void throwCheckedException() throws MyCheckedException {
        System.out.println("throwCheckedException: 抛出编译时异常");
        throw new MyCheckedException();
    }

    /**
     * 该方法会声明并抛出一个运行时异常，调用方不是必须处理异常
     */
    public static void throwUncheckedException() throws MyUncheckedException {
        System.out.println("throwUncheckedException: 抛出运行时异常");
        throw new MyUncheckedException();
    }

    /**
     * 演示关键字的使用
     */
    public static void tryCatchFinally() {
        try {
            throwCheckedException();
        } catch (MyCheckedException e) {
            // 编译时异常必须被处理
            // 可以将这个 catch 块删除，然后编译，会不通过
            System.out.println("tryCatchFinally: 处理编译时异常");
            e.printStackTrace();
        } finally {
            System.out.println("tryCatchFinally: finally 块一定会被执行");
        }

        try {
            // 不用去处理这个方法抛出的异常，照样可以编译成功，
            // 只不过在运行时不处理会导致线程结束
            throwUncheckedException();
        } catch (MyUncheckedException e) {
            // 可以将这个 catch 块删除，然后编译，可以通过
            // 再运行则会报错
            System.out.println("tryCatchFinally: 处理运行时异常");
            e.printStackTrace();
        } finally {
            System.out.println("tryCatchFinally: finally 块一定会被执行");
        }
    }

    /**
     * 演示 try-with-resources 的使用
     */
    public static void tryWithResources() {
        try (AutoCloseableResource r = new AutoCloseableResource()) {
            // doSomething
        } catch (Exception e) {
            System.out.println("tryWithResources: 处理异常");
        }
    }

    /**
     * try-finally 也搭配使用，不一定需要 catch 异常
     * 通常用在需要保证某部分代码一定需要被执行的情况，比如锁的释放
     */
    public static void tryFinally() {
        try {
            System.out.println("tryFinally: try 代码块");
        } finally {
            System.out.println("tryFinally: finally 代码块");
        }
    }

    public static void main(String[] args) throws Exception {
        tryCatchFinally();
        TimeUnit.SECONDS.sleep(1);
        System.out.println("\n分割线 -------------------- \n");
        tryWithResources();

        System.out.println("\n分割线 -------------------- \n");
        tryFinally();
    }
}
