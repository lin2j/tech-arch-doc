public class ExceptionTest3 {
    
    public static void main(String[] args) {
        try {
            int a = 1;
        } finally {
            System.out.println("finnaly block");
        }
    }
}
