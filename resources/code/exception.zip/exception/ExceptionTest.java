public class ExceptionTest {

    public static void throwExcep() {
        int i = 1 / 0;
    }
    
    public static void main(String[] args) {
        try {
            throwExcep();
        } catch (ArithmeticException e1) {
            e1.printStackTrace();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }
}
